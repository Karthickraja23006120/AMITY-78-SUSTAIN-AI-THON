import "./globals.css"
import { Inter } from "next/font/google"
import Header from "./components/header"
import Footer from "./components/footer"
import { Toaster } from "@/components/ui/toaster"
import AuthProvider from "./components/auth-provider"
import ThemeProvider from "./components/theme-provider"
import { CartProvider } from "./lib/cart-context"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "EcoSustain - Environmental Sustainability Platform",
  description: "Track, improve, and collaborate on environmental sustainability efforts",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className={`${inter.className} min-h-screen flex flex-col`}>
        <ThemeProvider>
          <AuthProvider>
            <CartProvider>
              <Header />
              <main className="flex-grow">{children}</main>
              <Footer />
              <Toaster />
            </CartProvider>
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}

