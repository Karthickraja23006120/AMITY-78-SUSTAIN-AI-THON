import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { notFound } from "next/navigation"
import ImageWithFallback from "../../components/image-with-fallback"

const tipDetails = {
  "reduce-energy": {
    title: "Reduce Energy Consumption",
    image: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?q=80&w=3270&auto=format&fit=crop",
    description: "Making small changes in how we use energy can lead to significant environmental benefits.",
    tips: [
      {
        title: "Switch to LED Bulbs",
        description: "LED bulbs use up to 90% less energy than traditional incandescent bulbs and last much longer.",
      },
      {
        title: "Smart Power Strips",
        description: "Use smart power strips to eliminate phantom energy consumption from devices in standby mode.",
      },
      {
        title: "Natural Light",
        description: "Make use of natural light during the day and arrange your workspace near windows.",
      },
      {
        title: "Energy-Efficient Appliances",
        description: "Choose appliances with high energy efficiency ratings when replacing old ones.",
      },
      {
        title: "Regular Maintenance",
        description: "Keep your HVAC systems and appliances well-maintained for optimal energy efficiency.",
      },
    ],
  },
  "conserve-water": {
    title: "Conserve Water",
    image: "https://images.unsplash.com/photo-1589634749000-1e72ec00a13f?q=80&w=3270&auto=format&fit=crop",
    description:
      "Water conservation is crucial for environmental sustainability and reducing our ecological footprint.",
    tips: [
      {
        title: "Fix Leaks Promptly",
        description: "A small leak can waste thousands of gallons of water per year. Regular checks are important.",
      },
      {
        title: "Install Water-Efficient Fixtures",
        description: "Use low-flow showerheads and dual-flush toilets to reduce water consumption.",
      },
      {
        title: "Collect Rainwater",
        description: "Use rain barrels to collect rainwater for gardening and outdoor cleaning.",
      },
      {
        title: "Efficient Irrigation",
        description: "Water plants early morning or late evening to minimize evaporation.",
      },
      {
        title: "Reuse Greywater",
        description: "Use greywater from sinks and washing machines for watering plants or flushing toilets.",
      },
    ],
  },
  "eat-sustainably": {
    title: "Eat Sustainably",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?q=80&w=3270&auto=format&fit=crop",
    description:
      "Sustainable eating habits can significantly reduce your environmental impact while promoting better health.",
    tips: [
      {
        title: "Choose Local Products",
        description: "Buy from local farmers to reduce transportation emissions and support your community.",
      },
      {
        title: "Reduce Meat Consumption",
        description: "Try meat-free days and explore plant-based protein alternatives.",
      },
      {
        title: "Grow Your Own",
        description: "Start a small herb garden or grow simple vegetables at home.",
      },
      {
        title: "Minimize Food Waste",
        description: "Plan meals, use leftovers, and compost food scraps.",
      },
      {
        title: "Choose Seasonal Produce",
        description: "Seasonal fruits and vegetables require less energy to grow and transport.",
      },
    ],
  },
  "sustainable-transport": {
    title: "Use Sustainable Transportation",
    image: "https://images.unsplash.com/photo-1519003722824-194d4455a60c?q=80&w=3270&auto=format&fit=crop",
    description: "Sustainable transportation choices help reduce emissions and create cleaner, healthier cities.",
    tips: [
      {
        title: "Use Public Transit",
        description: "Take buses or trains for longer journeys to reduce individual carbon emissions.",
      },
      {
        title: "Bike or Walk",
        description: "Choose active transportation for short trips to improve health and reduce emissions.",
      },
      {
        title: "Carpool",
        description: "Share rides with colleagues or use carpooling apps to reduce vehicles on the road.",
      },
      {
        title: "Maintain Your Vehicle",
        description: "Regular maintenance ensures optimal fuel efficiency and reduces emissions.",
      },
      {
        title: "Consider Electric Vehicles",
        description: "When purchasing a new vehicle, explore electric or hybrid options.",
      },
    ],
  },
  "reduce-reuse-recycle": {
    title: "Reduce, Reuse, Recycle",
    image: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?q=80&w=3270&auto=format&fit=crop",
    description: "The three R's of sustainability are key to minimizing waste and conserving resources.",
    tips: [
      {
        title: "Avoid Single-Use Items",
        description: "Choose reusable alternatives to disposable products.",
      },
      {
        title: "Proper Recycling",
        description: "Learn local recycling guidelines and sort waste correctly.",
      },
      {
        title: "Upcycle",
        description: "Get creative with old items and give them new life through upcycling.",
      },
      {
        title: "Buy Second-Hand",
        description: "Consider second-hand items before buying new products.",
      },
      {
        title: "Minimize Packaging",
        description: "Choose products with minimal or recyclable packaging.",
      },
    ],
  },
  "eco-friendly-business": {
    title: "Support Eco-Friendly Businesses",
    image: "https://images.unsplash.com/photo-1605600659908-0ef719419d41?q=80&w=3270&auto=format&fit=crop",
    description: "Supporting sustainable businesses helps drive positive environmental change in the market.",
    tips: [
      {
        title: "Research Companies",
        description: "Look into companies' environmental policies and commitments.",
      },
      {
        title: "Choose Certified Products",
        description: "Look for environmental certifications like Energy Star, USDA Organic, or Fair Trade.",
      },
      {
        title: "Support Local",
        description: "Choose local businesses to reduce transportation impacts and support your community.",
      },
      {
        title: "Avoid Greenwashing",
        description: "Learn to identify genuine environmental commitments versus marketing claims.",
      },
      {
        title: "Give Feedback",
        description: "Communicate with businesses about their environmental practices.",
      },
    ],
  },
}

export default function TipDetail({ params }: { params: { slug: string } }) {
  const tip = tipDetails[params.slug as keyof typeof tipDetails]

  if (!tip) {
    notFound()
  }

  return (
    <div className="max-w-4xl mx-auto">
      <Button variant="ghost" className="mb-6" asChild>
        <Link href="/tips">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Tips
        </Link>
      </Button>

      <div className="relative h-[400px] rounded-xl overflow-hidden mb-8">
        <ImageWithFallback
          src={tip.image || "/placeholder.svg"}
          alt={tip.title}
          fill
          className="object-cover"
          priority
        />
      </div>

      <h1 className="text-4xl font-bold mb-4">{tip.title}</h1>
      <p className="text-xl text-gray-600 mb-12">{tip.description}</p>

      <div className="grid gap-6">
        {tip.tips.map((item, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
              <p className="text-gray-600">{item.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Ready to Make a Difference?</h2>
        <p className="text-gray-600 mb-6">Join our community and start tracking your environmental impact today.</p>
        <Button className="bg-green-600 hover:bg-green-700" asChild>
          <Link href="/signup">Get Started</Link>
        </Button>
      </div>
    </div>
  )
}

