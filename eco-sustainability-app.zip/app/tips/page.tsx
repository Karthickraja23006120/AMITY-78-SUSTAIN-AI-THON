import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import ImageWithFallback from "../components/image-with-fallback"
import Link from "next/link"

const tips = [
  {
    title: "Reduce Energy Consumption",
    description: "Switch to LED bulbs, unplug devices when not in use, and use natural light when possible.",
    image: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?q=80&w=3270&auto=format&fit=crop",
    alt: "LED light bulb saving energy",
    slug: "reduce-energy",
  },
  {
    title: "Conserve Water",
    description: "Fix leaks, take shorter showers, and collect rainwater for gardening.",
    image: "https://images.unsplash.com/photo-1589634749000-1e72ec00a13f?q=80&w=3270&auto=format&fit=crop",
    alt: "Water conservation concept",
    slug: "conserve-water",
  },
  {
    title: "Eat Sustainably",
    description: "Choose locally sourced, plant-based foods and reduce meat consumption.",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?q=80&w=3270&auto=format&fit=crop",
    alt: "Fresh organic vegetables and fruits",
    slug: "eat-sustainably",
  },
  {
    title: "Use Sustainable Transportation",
    description: "Walk, bike, or use public transport instead of driving when possible.",
    image: "https://images.unsplash.com/photo-1519003722824-194d4455a60c?q=80&w=3270&auto=format&fit=crop",
    alt: "Electric bicycle for sustainable transport",
    slug: "sustainable-transport",
  },
  {
    title: "Reduce, Reuse, Recycle",
    description: "Minimize waste, reuse items, and recycle materials properly.",
    image: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?q=80&w=3270&auto=format&fit=crop",
    alt: "Recycling bins",
    slug: "reduce-reuse-recycle",
  },
  {
    title: "Support Eco-Friendly Businesses",
    description: "Choose products and services from companies committed to sustainability.",
    image: "https://images.unsplash.com/photo-1605600659908-0ef719419d41?q=80&w=3270&auto=format&fit=crop",
    alt: "Eco-friendly products",
    slug: "eco-friendly-business",
  },
]

export default function EcoTips() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      <div className="container mx-auto px-6 py-16">
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-bold mb-4 text-gray-900">Sustainable Living Tips</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Simple ways to make a positive impact on our environment and create a more sustainable future.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {tips.map((tip, index) => (
            <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
              <div className="relative h-48 overflow-hidden">
                <ImageWithFallback
                  src={tip.image || "/placeholder.svg"}
                  alt={tip.alt}
                  fill
                  className="object-cover transform hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardHeader className="space-y-2">
                <CardTitle className="text-xl font-bold text-gray-900">{tip.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 leading-relaxed">{tip.description}</p>
                <Link
                  href={`/tips/${tip.slug}`}
                  className="mt-4 inline-block text-green-600 font-semibold hover:text-green-700 transition-colors duration-200"
                >
                  Learn more →
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 bg-green-600 rounded-2xl p-8 text-white text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Start Your Sustainable Journey?</h2>
          <p className="text-lg mb-6 max-w-2xl mx-auto">
            Join our community of environmentally conscious individuals making a difference.
          </p>
          <Link
            href="/signup"
            className="inline-block bg-white text-green-600 px-8 py-3 rounded-lg font-semibold hover:bg-green-50 transition-colors duration-200"
          >
            Get Started Today
          </Link>
        </div>
      </div>
    </div>
  )
}

