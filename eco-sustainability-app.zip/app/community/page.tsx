"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Heart, MessageSquare } from "lucide-react"
import { CreatePostDialog } from "../components/create-post-dialog"
import { CommentSection } from "../components/comment-section"
import ImageWithFallback from "../components/image-with-fallback"
import { useToast } from "@/components/ui/use-toast"

type Post = {
  id: number
  title: string
  author: string
  content: string
  image?: string
  likes: number
  comments: Array<{
    id: number
    author: string
    content: string
    timestamp: string
  }>
  isLiked?: boolean
  showComments?: boolean
}

export default function CommunityForum() {
  const [posts, setPosts] = useState<Post[]>([
    {
      id: 1,
      title: "Starting a Community Garden",
      author: "GreenThumb",
      content:
        "I'm interested in starting a community garden in my neighborhood. Looking for advice on getting started and building community support.",
      image: "https://images.unsplash.com/photo-1592150621744-aca64f48394a?q=80&w=2960&auto=format&fit=crop",
      likes: 24,
      comments: [
        {
          id: 1,
          author: "GardenPro",
          content:
            "Great initiative! Start by finding a suitable location and gathering interested neighbors. I can help with planning!",
          timestamp: "2024-01-19T10:00:00Z",
        },
      ],
      isLiked: false,
      showComments: false,
    },
    {
      id: 2,
      title: "Zero Waste Living Tips",
      author: "EcoWarrior",
      content:
        "Share your best tips for reducing waste in daily life. What are your favorite reusable alternatives to common disposable items?",
      image: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?q=80&w=3270&auto=format&fit=crop",
      likes: 45,
      comments: [
        {
          id: 1,
          author: "ZeroWastePro",
          content: "I switched to a safety razor and it's been amazing! No more plastic waste from disposable razors.",
          timestamp: "2024-01-19T09:00:00Z",
        },
      ],
      isLiked: false,
      showComments: false,
    },
  ])

  const { toast } = useToast()

  const handleLike = (postId: number) => {
    setPosts(
      posts.map((post) => {
        if (post.id === postId) {
          return {
            ...post,
            likes: post.isLiked ? post.likes - 1 : post.likes + 1,
            isLiked: !post.isLiked,
          }
        }
        return post
      }),
    )
  }

  const toggleComments = (postId: number) => {
    setPosts(
      posts.map((post) => {
        if (post.id === postId) {
          return {
            ...post,
            showComments: !post.showComments,
          }
        }
        return post
      }),
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900">Community Forum</h1>
            <CreatePostDialog />
          </div>

          <Tabs defaultValue="discussions" className="mb-8">
            <TabsList className="grid w-full grid-cols-3 lg:w-[400px]">
              <TabsTrigger value="discussions">Discussions</TabsTrigger>
              <TabsTrigger value="projects">Projects</TabsTrigger>
              <TabsTrigger value="events">Events</TabsTrigger>
            </TabsList>

            <TabsContent value="discussions">
              <div className="space-y-6">
                {posts.map((post) => (
                  <Card key={post.id}>
                    <CardHeader>
                      <div className="flex items-center space-x-4">
                        <Avatar>
                          <AvatarImage src={`https://api.dicebear.com/6.x/initials/svg?seed=${post.author}`} />
                          <AvatarFallback>{post.author[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <CardTitle className="text-xl">{post.title}</CardTitle>
                          <p className="text-sm text-gray-500">Posted by {post.author}</p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 mb-4">{post.content}</p>
                      {post.image && (
                        <div className="relative h-[300px] rounded-lg overflow-hidden mb-4">
                          <ImageWithFallback
                            src={post.image || "/placeholder.svg"}
                            alt={post.title}
                            fill
                            className="object-cover"
                          />
                        </div>
                      )}
                    </CardContent>
                    <CardFooter className="flex flex-col space-y-4">
                      <div className="flex justify-between w-full">
                        <div className="flex space-x-4">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleLike(post.id)}
                            className={post.isLiked ? "text-green-600" : ""}
                          >
                            <Heart className={`h-4 w-4 mr-2 ${post.isLiked ? "fill-green-600" : ""}`} />
                            {post.likes}
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => toggleComments(post.id)}>
                            <MessageSquare className="h-4 w-4 mr-2" />
                            {post.comments.length}
                          </Button>
                        </div>
                      </div>
                      {post.showComments && (
                        <div className="w-full pt-4 border-t">
                          <CommentSection postId={post.id} initialComments={post.comments} />
                        </div>
                      )}
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="projects">
              <Card>
                <CardHeader>
                  <CardTitle>Community Projects</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Join or create local environmental projects. Coming soon!</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="events">
              <Card>
                <CardHeader>
                  <CardTitle>Upcoming Events</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Find and join environmental events in your area. Coming soon!</p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

