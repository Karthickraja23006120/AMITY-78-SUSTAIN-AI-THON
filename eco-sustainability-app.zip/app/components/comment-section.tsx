"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/components/ui/use-toast"

type Comment = {
  id: number
  author: string
  content: string
  timestamp: string
}

export function CommentSection({
  postId,
  initialComments,
}: {
  postId: number
  initialComments: Comment[]
}) {
  const [comments, setComments] = useState<Comment[]>(initialComments)
  const [newComment, setNewComment] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newComment.trim()) return

    setIsSubmitting(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const comment: Comment = {
      id: Date.now(),
      author: "Current User",
      content: newComment,
      timestamp: new Date().toISOString(),
    }

    setComments((prev) => [comment, ...prev])
    setNewComment("")
    setIsSubmitting(false)

    toast({
      title: "Comment Added",
      description: "Your comment has been posted successfully!",
    })
  }

  return (
    <div className="space-y-4">
      <form onSubmit={handleSubmit} className="space-y-4">
        <Textarea
          placeholder="Add a comment..."
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          className="min-h-[100px]"
        />
        <Button type="submit" disabled={isSubmitting || !newComment.trim()} className="bg-green-600 hover:bg-green-700">
          {isSubmitting ? "Posting..." : "Post Comment"}
        </Button>
      </form>

      <div className="space-y-4">
        {comments.map((comment) => (
          <div key={comment.id} className="flex gap-4 p-4 bg-gray-50 rounded-lg">
            <Avatar>
              <AvatarImage src={`https://api.dicebear.com/6.x/initials/svg?seed=${comment.author}`} />
              <AvatarFallback>{comment.author[0]}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold">{comment.author}</h4>
                <span className="text-sm text-gray-500">{new Date(comment.timestamp).toLocaleDateString()}</span>
              </div>
              <p className="mt-1 text-gray-600">{comment.content}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

