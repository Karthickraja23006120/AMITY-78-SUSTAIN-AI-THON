"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"

type Activity = {
  type: string
  amount: number
  unit: string
  impact: number
}

type AddActivityFormProps = {
  onActivityAdded: (activity: Activity) => void
}

export function AddActivityForm({ onActivityAdded }: AddActivityFormProps) {
  const [activityType, setActivityType] = useState("")
  const [amount, setAmount] = useState("")
  const { toast } = useToast()

  const activityTypes = [
    { value: "bike", label: "Biking", unit: "km", impactPerUnit: -0.2 },
    { value: "plant", label: "Planting Trees", unit: "trees", impactPerUnit: -20 },
    { value: "recycle", label: "Recycling", unit: "kg", impactPerUnit: -1.5 },
    { value: "renewable", label: "Using Renewable Energy", unit: "kWh", impactPerUnit: -0.5 },
  ]

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const selectedActivity = activityTypes.find((a) => a.value === activityType)
    if (selectedActivity && amount) {
      const numericAmount = Number.parseFloat(amount)
      const activity: Activity = {
        type: selectedActivity.label,
        amount: numericAmount,
        unit: selectedActivity.unit,
        impact: numericAmount * selectedActivity.impactPerUnit,
      }
      onActivityAdded(activity)
      setActivityType("")
      setAmount("")
      toast({
        title: "Activity Added",
        description: `You've added: ${activity.type} - ${activity.amount} ${activity.unit}`,
      })
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="activity-type">Activity Type</Label>
        <Select value={activityType} onValueChange={setActivityType}>
          <SelectTrigger id="activity-type">
            <SelectValue placeholder="Select an activity" />
          </SelectTrigger>
          <SelectContent>
            {activityTypes.map((type) => (
              <SelectItem key={type.value} value={type.value}>
                {type.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label htmlFor="amount">Amount</Label>
        <Input
          id="amount"
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="Enter amount"
        />
      </div>
      <Button type="submit" className="w-full">
        Add Activity
      </Button>
    </form>
  )
}

