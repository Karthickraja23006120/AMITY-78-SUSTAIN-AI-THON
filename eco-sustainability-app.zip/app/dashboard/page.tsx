"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import Link from "next/link"
import { ArrowDown, ArrowUp, Leaf, Car, Zap, Droplets } from "lucide-react"
import { AddActivityForm } from "../components/add-activity-form"

// Sample data for the chart
const initialData = [
  { month: "Jan", footprint: 4.2 },
  { month: "Feb", footprint: 3.8 },
  { month: "Mar", footprint: 3.5 },
  { month: "Apr", footprint: 3.2 },
  { month: "May", footprint: 2.9 },
  { month: "Jun", footprint: 2.7 },
]

const stats = [
  {
    title: "Total Carbon Savings",
    value: "1.5",
    unit: "tons CO2",
    change: "-12%",
    trend: "down",
    icon: Leaf,
  },
  {
    title: "Transport Emissions",
    value: "0.8",
    unit: "tons CO2",
    change: "-8%",
    trend: "down",
    icon: Car,
  },
  {
    title: "Energy Usage",
    value: "245",
    unit: "kWh",
    change: "+2%",
    trend: "up",
    icon: Zap,
  },
  {
    title: "Water Consumption",
    value: "156",
    unit: "gallons",
    change: "-5%",
    trend: "down",
    icon: Droplets,
  },
]

type Activity = {
  type: string
  amount: number
  unit: string
  impact: number
}

export default function Dashboard() {
  const [chartData, setChartData] = useState(initialData)
  const [recentActivities, setRecentActivities] = useState<Activity[]>([])
  const [totalImpact, setTotalImpact] = useState(0)

  const handleActivityAdded = (activity: Activity) => {
    // Update recent activities
    setRecentActivities((prev) => [activity, ...prev.slice(0, 2)])

    // Update total impact
    setTotalImpact((prev) => prev + activity.impact)

    // Update chart data (simplified for demo purposes)
    setChartData((prev) => {
      const lastMonth = prev[prev.length - 1]
      return [
        ...prev.slice(0, -1),
        { ...lastMonth, footprint: Math.max(0, lastMonth.footprint + activity.impact / 1000) },
      ]
    })
  }

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <div className="flex items-center space-x-2">
          <Button className="bg-green-600 hover:bg-green-700">
            <Link href="/calculator">Calculate Footprint</Link>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {stats.map((stat) => (
              <Card key={stat.title}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                  <stat.icon className="h-4 w-4 text-green-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {stat.value}
                    <span className="text-sm font-normal text-gray-500 ml-1">{stat.unit}</span>
                  </div>
                  <p
                    className={`text-xs ${stat.trend === "down" ? "text-green-600" : "text-red-600"} flex items-center`}
                  >
                    {stat.trend === "down" ? (
                      <ArrowDown className="h-4 w-4 mr-1" />
                    ) : (
                      <ArrowUp className="h-4 w-4 mr-1" />
                    )}
                    {stat.change} from last month
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            <Card className="col-span-4">
              <CardHeader>
                <CardTitle>Carbon Footprint Overview</CardTitle>
                <CardDescription>Your carbon emissions over the past 6 months</CardDescription>
              </CardHeader>
              <CardContent className="pl-2">
                <ResponsiveContainer width="100%" height={350}>
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="footprint" stroke="#16a34a" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="col-span-3">
              <CardHeader>
                <CardTitle>Recent Activities</CardTitle>
                <CardDescription>Your latest environmental actions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  {recentActivities.map((activity, index) => (
                    <div key={index} className="flex items-center">
                      <div className="space-y-1">
                        <p className="text-sm font-medium leading-none">{activity.type}</p>
                        <p className="text-sm text-muted-foreground">
                          {activity.amount} {activity.unit}
                        </p>
                      </div>
                      <div className="ml-auto font-medium text-green-600">{activity.impact.toFixed(2)} kg CO2e</div>
                    </div>
                  ))}
                  {recentActivities.length === 0 && (
                    <p className="text-sm text-muted-foreground">No recent activities. Add one below!</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Add New Activity</CardTitle>
              <CardDescription>Record your eco-friendly actions to see their impact</CardDescription>
            </CardHeader>
            <CardContent>
              <AddActivityForm onActivityAdded={handleActivityAdded} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Total Impact</CardTitle>
              <CardDescription>Your cumulative environmental impact</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-green-600">
                {totalImpact.toFixed(2)} <span className="text-base font-normal text-gray-500">kg CO2e saved</span>
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Detailed Analytics</CardTitle>
              <CardDescription>Coming soon: Advanced insights into your environmental impact</CardDescription>
            </CardHeader>
            <CardContent>
              <p>This feature is under development.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Environmental Reports</CardTitle>
              <CardDescription>Coming soon: Generate detailed reports of your sustainability journey</CardDescription>
            </CardHeader>
            <CardContent>
              <p>This feature is under development.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

