import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from 'next/image'

const products = [
  {
    id: 1,
    name: "Reusable Water Bottle",
    description: "Durable, BPA-free water bottle made from recycled materials.",
    price: 19.99,
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 2,
    name: "Bamboo Cutlery Set",
    description: "Eco-friendly travel cutlery set made from sustainable bamboo.",
    price: 14.99,
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 3,
    name: "Organic Cotton Tote Bag",
    description: "Sturdy, reusable shopping bag made from 100% organic cotton.",
    price: 9.99,
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 4,
    name: "Solar-Powered Charger",
    description: "Portable solar panel for charging your devices on the go.",
    price: 39.99,
    image: "/placeholder.svg?height=200&width=200",
  },
]

export default function EcoMarketplace() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Eco-Friendly Marketplace</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <Card key={product.id}>
            <CardHeader>
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                width={200}
                height={200}
                className="mx-auto"
              />
              <CardTitle>{product.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p>{product.description}</p>
              <p className="text-lg font-bold mt-2">${product.price.toFixed(2)}</p>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Add to Cart</Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

