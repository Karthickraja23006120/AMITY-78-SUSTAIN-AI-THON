"use client"

import { useAuth } from "../lib/auth-context"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Leaf, Trophy, Award, Medal } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export default function Profile() {
  const { user, setUser } = useAuth()
  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    bio: "Passionate about environmental sustainability",
  })
  const { toast } = useToast()

  const achievements = [
    {
      title: "Carbon Reducer",
      description: "Reduced carbon footprint by 20%",
      icon: Leaf,
      date: "Earned 2 months ago",
    },
    {
      title: "Eco Champion",
      description: "Completed 50 sustainable actions",
      icon: Trophy,
      date: "Earned 1 month ago",
    },
    {
      title: "Community Leader",
      description: "Helped 10 others reduce their footprint",
      icon: Award,
      date: "Earned 2 weeks ago",
    },
    {
      title: "Sustainability Expert",
      description: "Achieved perfect eco-score for 3 months",
      icon: Medal,
      date: "Earned 1 week ago",
    },
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, you would update the user profile here
    toast({
      title: "Profile Updated",
      description: "Your profile has been updated successfully.",
    })
    setIsEditing(false)
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p>Please log in to view your profile.</p>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center space-x-8 mb-8">
          <Avatar className="h-24 w-24">
            <AvatarFallback className="bg-green-100 text-green-600 text-2xl">
              {user.name?.[0] ?? user.email[0].toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div>
            <h1 className="text-3xl font-bold">{user.name}</h1>
            <p className="text-gray-600">{user.email}</p>
            <div className="flex space-x-2 mt-2">
              <Badge variant="secondary">Carbon Warrior</Badge>
              <Badge variant="secondary">Top Contributor</Badge>
            </div>
          </div>
        </div>

        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="settings">Profile Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Environmental Impact</CardTitle>
                  <CardDescription>Your contribution to sustainability</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm font-medium">Carbon Reduction</p>
                      <h3 className="text-2xl font-bold text-green-600">2.5 tons</h3>
                      <p className="text-sm text-gray-500">Total CO2 saved</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Sustainable Actions</p>
                      <h3 className="text-2xl font-bold text-green-600">127</h3>
                      <p className="text-sm text-gray-500">Completed activities</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Community Impact</CardTitle>
                  <CardDescription>Your influence on others</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm font-medium">Inspired Users</p>
                      <h3 className="text-2xl font-bold text-green-600">15</h3>
                      <p className="text-sm text-gray-500">People following your journey</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Shared Tips</p>
                      <h3 className="text-2xl font-bold text-green-600">34</h3>
                      <p className="text-sm text-gray-500">Eco-friendly suggestions</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="achievements">
            <div className="grid gap-4 md:grid-cols-2">
              {achievements.map((achievement, index) => (
                <Card key={index}>
                  <CardHeader>
                    <div className="flex items-center space-x-4">
                      <div className="p-2 bg-green-100 rounded-lg">
                        <achievement.icon className="h-6 w-6 text-green-600" />
                      </div>
                      <div>
                        <CardTitle>{achievement.title}</CardTitle>
                        <CardDescription>{achievement.description}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardFooter>
                    <p className="text-sm text-gray-500">{achievement.date}</p>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Profile Settings</CardTitle>
                <CardDescription>Update your profile information</CardDescription>
              </CardHeader>
              <form onSubmit={handleSubmit}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bio">Bio</Label>
                    <Input
                      id="bio"
                      value={formData.bio}
                      onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button type="submit" className="bg-green-600 hover:bg-green-700">
                    Save Changes
                  </Button>
                </CardFooter>
              </form>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

