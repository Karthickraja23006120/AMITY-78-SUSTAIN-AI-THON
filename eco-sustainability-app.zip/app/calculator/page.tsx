"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import ImageWithFallback from "../components/image-with-fallback"

export default function CarbonCalculator() {
  const [electricity, setElectricity] = useState("")
  const [gas, setGas] = useState("")
  const [car, setCar] = useState("")
  const [flights, setFlights] = useState("")
  const [result, setResult] = useState<number | null>(null)

  const calculateFootprint = () => {
    const footprint =
      Number(electricity) * 0.0005 + Number(gas) * 0.00018 + Number(car) * 0.0002 + Number(flights) * 1.2
    setResult(Number(footprint.toFixed(2)))
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-6 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Carbon Footprint Calculator</h1>
            <p className="text-lg text-gray-600">
              Calculate your environmental impact and discover ways to reduce your carbon footprint
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="md:order-1">
              <CardHeader>
                <CardTitle>Enter Your Usage</CardTitle>
              </CardHeader>
              <CardContent>
                <form
                  onSubmit={(e) => {
                    e.preventDefault()
                    calculateFootprint()
                  }}
                  className="space-y-6"
                >
                  <div className="space-y-2">
                    <Label htmlFor="electricity">Electricity (kWh/month)</Label>
                    <Input
                      id="electricity"
                      type="number"
                      value={electricity}
                      onChange={(e) => setElectricity(e.target.value)}
                      className="text-lg"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="gas">Natural Gas (therms/month)</Label>
                    <Input
                      id="gas"
                      type="number"
                      value={gas}
                      onChange={(e) => setGas(e.target.value)}
                      className="text-lg"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="car">Car Travel (miles/month)</Label>
                    <Input
                      id="car"
                      type="number"
                      value={car}
                      onChange={(e) => setCar(e.target.value)}
                      className="text-lg"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="flights">Flights (hours/month)</Label>
                    <Input
                      id="flights"
                      type="number"
                      value={flights}
                      onChange={(e) => setFlights(e.target.value)}
                      className="text-lg"
                    />
                  </div>
                  <Button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-lg py-6">
                    Calculate
                  </Button>
                </form>
              </CardContent>
            </Card>

            <div className="space-y-8">
              <Card className="bg-white">
                <CardHeader>
                  <CardTitle>Your Carbon Footprint</CardTitle>
                </CardHeader>
                <CardContent>
                  {result !== null ? (
                    <div className="text-center py-8">
                      <p className="text-6xl font-bold text-green-600 mb-2">{result}</p>
                      <p className="text-xl text-gray-600">tons CO2e/year</p>
                      <div className="mt-6 text-left">
                        <h3 className="font-semibold mb-2">What does this mean?</h3>
                        <p className="text-gray-600">
                          The average carbon footprint is 4 tons per year. Your result shows how your lifestyle impacts
                          the environment.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12 text-gray-500">
                      Enter your usage data and click calculate to see your carbon footprint
                    </div>
                  )}
                </CardContent>
              </Card>

              <div className="relative h-64 rounded-lg overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?q=80&w=3270&auto=format&fit=crop"
                  alt="Environmental impact visualization"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

