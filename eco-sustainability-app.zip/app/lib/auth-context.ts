"use client"

import { createContext, useContext } from "react"
import type { User } from "./auth"

export type AuthContextType = {
  user: User | null
  setUser: (user: User | null) => void
}

export const AuthContext = createContext<AuthContextType>({
  user: null,
  setUser: () => {},
})

export const useAuth = () => useContext(AuthContext)

