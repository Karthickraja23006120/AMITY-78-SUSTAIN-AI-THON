"use server"

import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { revalidatePath } from "next/cache"

export type User = {
  id: string
  email: string
  name?: string
}

export async function signIn(formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string

  // In a real app, validate credentials against a database
  if (email && password) {
    // Demo user for testing
    const user: User = {
      id: "1",
      email: email,
      name: email.split("@")[0],
    }

    // Set session cookie
    cookies().set("session", JSON.stringify(user), {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 1 week
    })

    revalidatePath("/")
    redirect("/dashboard")
  }

  return { error: "Invalid credentials" }
}

export async function signUp(formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string
  const name = formData.get("name") as string

  // In a real app, create user in database
  if (email && password) {
    const user: User = {
      id: "1",
      email: email,
      name: name || email.split("@")[0],
    }

    // Set session cookie
    cookies().set("session", JSON.stringify(user), {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 1 week
    })

    revalidatePath("/")
    redirect("/dashboard")
  }

  return { error: "Invalid input" }
}

export async function signOut() {
  cookies().delete("session")
  revalidatePath("/")
  redirect("/")
}

export async function getUser(): Promise<User | null> {
  const session = cookies().get("session")
  if (!session) return null

  try {
    return JSON.parse(session.value) as User
  } catch {
    return null
  }
}

