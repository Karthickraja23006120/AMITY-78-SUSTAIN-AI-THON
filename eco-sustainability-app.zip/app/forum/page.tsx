import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"

const posts = [
  {
    id: 1,
    title: "How to start a community garden?",
    author: "GreenThumb",
    content: "I'm interested in starting a community garden in my neighborhood. Does anyone have experience with this? What are the first steps I should take?",
    likes: 15,
    comments: 7,
  },
  {
    id: 2,
    title: "Best practices for home composting",
    author: "EcoWarrior",
    content: "I've been composting at home for a while now, and I'd love to share some tips and tricks I've learned. What has worked well for you?",
    likes: 23,
    comments: 12,
  },
  {
    id: 3,
    title: "Reducing plastic waste in daily life",
    author: "PlasticFighter",
    content: "I'm trying to cut down on my plastic usage. What are some easy swaps you've made to reduce plastic in your daily life?",
    likes: 31,
    comments: 18,
  },
]

export default function CommunityForum() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Community Forum</h1>
      <div className="space-y-6">
        {posts.map((post) => (
          <Card key={post.id}>
            <CardHeader>
              <CardTitle>{post.title}</CardTitle>
              <div className="flex items-center space-x-2">
                <Avatar>
                  <AvatarImage src={`https://api.dicebear.com/6.x/initials/svg?seed=${post.author}`} />
                  <AvatarFallback>{post.author[0]}</AvatarFallback>
                </Avatar>
                <span>{post.author}</span>
              </div>
            </CardHeader>
            <CardContent>
              <p>{post.content}</p>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">Like ({post.likes})</Button>
              <Button variant="outline">Comment ({post.comments})</Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

