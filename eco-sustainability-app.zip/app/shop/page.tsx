"use client"

import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import ImageWithFallback from "../components/image-with-fallback"
import { useCart } from "../lib/cart-context"
import { useToast } from "@/components/ui/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const products = [
  {
    id: 1,
    name: "Bamboo Water Bottle",
    price: 24.99,
    category: "Lifestyle",
    description: "Sustainable bamboo water bottle with stainless steel interior.",
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?q=80&w=3270&auto=format&fit=crop",
  },
  {
    id: 2,
    name: "Organic Cotton Tote",
    price: 19.99,
    category: "Bags",
    description: "100% organic cotton tote bag for your shopping needs.",
    image: "https://images.unsplash.com/photo-1605600659908-0ef719419d41?q=80&w=3270&auto=format&fit=crop",
  },
  {
    id: 3,
    name: "Bamboo Cutlery Set",
    price: 15.99,
    category: "Kitchen",
    description: "Portable bamboo cutlery set with carrying case.",
    image: "https://images.unsplash.com/photo-1584346133934-a3afd2a33c4c?q=80&w=3270&auto=format&fit=crop",
  },
  {
    id: 4,
    name: "Solar Power Bank",
    price: 49.99,
    category: "Electronics",
    description: "Portable solar-powered charger for your devices.",
    image: "https://images.unsplash.com/photo-1617788138017-80ad40651399?q=80&w=3270&auto=format&fit=crop",
  },
  {
    id: 5,
    name: "Reusable Coffee Cup",
    price: 29.99,
    category: "Kitchen",
    description: "Insulated reusable coffee cup made from recycled materials.",
    image: "https://images.unsplash.com/photo-1577937927133-66ef06acdf18?q=80&w=3270&auto=format&fit=crop",
  },
  {
    id: 6,
    name: "Eco-friendly Backpack",
    price: 79.99,
    category: "Bags",
    description: "Sustainable backpack made from recycled ocean plastics.",
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=3270&auto=format&fit=crop",
  },
]

export default function Shop() {
  const { addItem } = useCart()
  const { toast } = useToast()

  const handleAddToCart = (product: (typeof products)[0]) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: 1,
      image: product.image,
      category: product.category,
    })
    toast({
      title: "Added to Cart",
      description: `${product.name} has been added to your cart.`,
    })
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-6 py-12">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-12">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Eco Shop</h1>
            <p className="text-lg text-gray-600">Sustainable products for a better tomorrow</p>
          </div>
          <div className="flex gap-4">
            <Select defaultValue="all">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="lifestyle">Lifestyle</SelectItem>
                <SelectItem value="kitchen">Kitchen</SelectItem>
                <SelectItem value="bags">Bags</SelectItem>
                <SelectItem value="electronics">Electronics</SelectItem>
              </SelectContent>
            </Select>
            <Select defaultValue="featured">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="featured">Featured</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="newest">Newest</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
              <div className="relative h-64">
                <ImageWithFallback
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  fill
                  className="object-cover"
                />
              </div>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl mb-1">{product.name}</CardTitle>
                    <span className="text-sm text-gray-500">{product.category}</span>
                  </div>
                  <span className="text-xl font-bold text-green-600">${product.price}</span>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">{product.description}</p>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-green-600 hover:bg-green-700" onClick={() => handleAddToCart(product)}>
                  Add to Cart
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}

