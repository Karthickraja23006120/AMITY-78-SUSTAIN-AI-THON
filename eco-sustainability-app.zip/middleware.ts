import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export function middleware(request: NextRequest) {
  const session = request.cookies.get('session')
  
  // List of protected routes that require authentication
  const protectedRoutes = [
    '/dashboard',
    '/calculator',
    '/profile',
    '/settings'
  ]

  // Check if the requested path is in protectedRoutes
  if (protectedRoutes.some(route => request.nextUrl.pathname.startsWith(route))) {
    if (!session) {
      const response = NextResponse.redirect(new URL('/login', request.url))
      response.cookies.delete('session')
      return response
    }
  }

  // List of auth routes that should redirect to dashboard if user is logged in
  const authRoutes = ['/login', '/signup']
  
  if (authRoutes.includes(request.nextUrl.pathname) && session) {
    return NextResponse.redirect(new URL('/dashboard', request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    '/dashboard/:path*',
    '/calculator/:path*',
    '/profile/:path*',
    '/settings/:path*',
    '/login',
    '/signup'
  ]
}

